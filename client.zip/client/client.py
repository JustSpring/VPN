import ssl
import socket
from shared.config import Addreses

class Client:
    def create_ssl_context(self):
        context = ssl.create_default_context(ssl.Purpose.CLIENT_AUTH)
        # Load the server's certificate and private key
        context.load_cert_chain(certfile="certificates/client_cert.pem", keyfile="certificates/client_key.pem")
        return context

    def create_client_socket(self, context, host=Addreses.SERVER_IP, port=Addreses.SERVER_PORT):
        # Create a TCP socket
        client_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

        # Bind the socket to the specified address and port
        print((host, port))
        client_socket.connect((host,port))

        print(f"Client connected to {Addreses.SERVER_IP}:{Addreses.SERVER_PORT}")

        # Wrap the socket with SSL/TLS for secure communication
        secure_socket = context.wrap_socket(client_socket, server_side=False)

        return secure_socket

client= Client()
secure_socket=client.create_client_socket(client.create_ssl_context())
print(secure_socket.recv(1024))